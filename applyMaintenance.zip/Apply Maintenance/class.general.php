<?php
    
	class General
    {

		function getLanguage()
        {
			if(isset($_SESSION['language'])) {
		        $language = $_SESSION['language'];
		    } else {
		    	if(isset($_COOKIE["language"])) {
		    		$_SESSION['language'] = $_COOKIE['language'];
			        $language = $_COOKIE['language'];
		    	} else {
		    		$getCountryCode = $_SERVER["HTTP_CF_IPCOUNTRY"];
		    		
		    		if ($getCountryCode == "CN" || $getCountryCode == "TW" || $getCountryCode == "HK" || $getCountryCode == "MO") {
			    		$_SESSION['language'] = "chineseSimplified";
				        $language = "chineseSimplified";
				        setcookie("language", "chineseSimplified");
		    		} else {
			    		$_SESSION['language'] = "english";
				        $language = "english";
				        setcookie("language", "english");
		    		}

		    		
		    	}
		    }

		    return $language;
		}

		function checkMaintenance(){
            include($_SERVER["DOCUMENT_ROOT"]."/include/config.php");
            
            $checkMaintenance = 0;

            if(!$toLoginPage) $toLoginPage = 0;
            $today = strtolower(date("l"));
            
            if($config["startTs"] && $config["endTs"]){
                if((strtotime(date("Y-m-d H:i:s")) >= strtotime($config["startTs"])) && (strtotime(date("Y-m-d H:i:s")) <= strtotime($config["endTs"]))){
                    $checkMaintenance = 1;
                }
            }

            return $checkMaintenance;
        }
	}

	?>
