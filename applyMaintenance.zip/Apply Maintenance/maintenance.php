<?php include 'include/config.php'; ?>
<?php include 'head.php'; ?>

<?php
   if((strtotime(date("Y-m-d H:i:s")) >= strtotime($config["startTs"])) && (strtotime(date("Y-m-d H:i:s")) <= strtotime($config["endTs"]))){
       $startTime = $config["startTs"];
       $endTime = $config["endTs"];

       $englishStartTime = strtotime($config["startTs"]);
       $englishStartTime = date("d F Y h:ia", $englishStartTime);

       $englishEndTime = strtotime($config["endTs"]);
       $englishEndTime = date("d F Y h:ia", $englishEndTime);

       $chineseStartTime = strtotime($config["startTs"]);
       $chineseStartTime = date("Y年m月d日H:i", $chineseStartTime);

       $chineseEndTime = strtotime($config["endTs"]);
       $chineseEndTime = date("Y年m月d日H:i時", $chineseEndTime);

   }else{
       echo '<script>window.location.href="login.php";</script>';
       exit();
   }
?>

<link href="css/login.css?v=<?php echo filemtime('css/login.css'); ?>" rel="stylesheet" type="text/css" />

<body  class="kt-page--loading-enabled kt-page--loading kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header--minimize-topbar kt-header-mobile--fixed kt-subheader--enabled kt-subheader--transparent kt-page--loading" style="background-color: #f8f8f8">


    
    
    <section class="loginPage maintenancePage">
        
        <div class="kt-container" style="min-height: calc(100vh - 63px);">
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <div class="row justify-content-center">
                            <div class="col-12 text-center my-5">
                                <img src="images/project/logo.png" class="maintainanceLogo">
                            </div>
                            <div class="col-lg-8 col-12 mt-5 maintainanceTitle">
                                Dear Valued Members,
                            </div>
                            <div class="col-lg-8 col-12 mt-2 maintainanceContent">
                                <?php echo $config['companyName']; ?> website will be undergoing maintenance on <?php echo $englishStartTime." till ".$englishEndTime; ?> We seek your kind understanding with regards to any inconvenience cause. Thank you for your patience.
                            </div>

                            <div class="col-lg-8 col-12 mt-5 maintainanceTitle">
                                各位尊敬的会员，
                            </div>
                            <div class="col-lg-8 col-12 mt-2 maintainanceContent">
                                <?php echo $config['companyName']; ?> 网站将于<?php echo $chineseStartTime."至".$chineseEndTime; ?>进行维修工作。为此所带来的不便公司恳请各位会员敬请谅解。感谢您的耐心等候。
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'footerLogin.php'; ?>

        
    </section>



</body>

</html>

<script>


</script>
